# 413 Request Entity Too Large when uploading initial presentation

### Description
An error occurs when a user tries to upload a large presentation file (e.g., a PDF) under the "Initial presentation" field in the Video Channel admin room settings. Instead of a clean validation message, a raw HTML error popup is displayed.

### Steps to Reproduce
1. Navigate to any Video Channel administration room.
2. Click on the file upload button next to **Initial presentation**.
3. Select a large file (in my case, `Sample.pdf`, which is ~23.3 MB).

### Expected Behavior
The system should either successfully upload the file or show a user-friendly error message indicating that the file size exceeds the maximum allowed limit. The maximum allowed size must be made known to the user before the upload is attempted. The page that boots the video channel must carry that limit, alongside the address the upload is sent to, and the limit the user is told must be exactly the limit the server actually accepts. A presentation of that size is stored, and one byte more is refused for its size.

### Actual Behavior
See the attached screenshot.

## Attached visual evidence
- `/app/.harbor_assets/bug_screenshot_1.png` — the report's visual evidence.

Read the screenshot before making changes.
