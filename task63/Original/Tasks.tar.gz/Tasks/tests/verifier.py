#!/usr/bin/env python3
"""Reward computation for fossasia__eventyay-3832-mm.

Parses the JUnit XML report emitted by test.sh and computes the reward from
config.json's f2p/p2p lists. NEVER inspects candidate source — only the test report.

Reward policy — BINARY, there is no partial credit:
  1.0  -- every f2p test passes AND every p2p test still passes.
  0.0  -- anything else, including a strict non-empty subset of f2p passing, a
          p2p regression, or no report at all.

A half-fix is a fail. Collapsing the middle loses nothing: the four count keys in
reward.json (f2p_passed / f2p_total / p2p_passed / p2p_total) already carry how
close the submission got, and any middle rung would let a half-fix read as "solved"
to pass@k.

This task ships no tests/rubrics.json and no tests/judge.py (Mode B), so the
--rubric plumbing below is inert: no verdict is ever handed in and rubric_passed
is always -1. It is kept so the verifier shape is uniform across the corpus and
the task is rubric-ready without a rewrite.
"""
import atexit
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

CONF = json.load(open('/tests/config.json'))
F2P, P2P = CONF['f2p'], CONF['p2p']
REPORT = '/logs/verifier/report.xml'
REWARD_JSON = '/logs/verifier/reward.json'
REWARD_TXT = '/logs/verifier/reward.txt'

# reward.json MUST be a FLAT map of numbers with exactly these seven keys. harbor parses
# it as VerifierResult.rewards: dict[str, float | int] and prefers it over reward.txt; a
# nested dict, list, string or None raises a pydantic ValidationError that aborts the
# trial BEFORE any reward is recorded — while reward.txt is still written inside the
# container, so the run looks scored when harbor in fact stored nothing.
_canon = {}


def canon_reward(f2p_results, p2p_results, rubric):
    """THE reward policy. Binary; a failed rubric can only ever withhold a 1.0.

    Takes the per-test verdict maps rather than bare counts, because the nop control needs
    PER-TEST outcomes to prove each f2p test individually detects the bug. An f2p test that
    passes on an empty submission is inert — it grades nothing — and only per-test detail
    from the nop run can expose that; the aggregate count cannot.
    """
    f2p_ok = {k: (v == 'pass') for k, v in f2p_results.items()}
    p2p_ok = {k: (v == 'pass') for k, v in p2p_results.items()}
    f, t = sum(f2p_ok.values()), len(f2p_ok)
    p, q = sum(p2p_ok.values()), len(p2p_ok)
    solved = bool(t) and f == t and p == q
    tests_passed = 1.0 if solved else 0.0
    _canon.clear()
    _canon.update({
        'reward': 0.0 if rubric == 'fail' else tests_passed,
        'tests_passed': tests_passed,
        'f2p_passed': f, 'f2p_total': t,
        'p2p_passed': p, 'p2p_total': q,
        'rubric_passed': {'pass': 1, 'fail': 0}.get(rubric, -1),
    })
    # Per-test detail rides along as extra SCALAR keys in the SAME flat dict — never as a
    # nested map, which harbor would reject with a ValidationError. Keyed by the full
    # config.json identifier so duplicate leaf names cannot collide.
    for name, passed in f2p_ok.items():
        _canon[f'f2p::{name}'] = 1.0 if passed else 0.0
    for name, passed in p2p_ok.items():
        _canon[f'p2p::{name}'] = 1.0 if passed else 0.0
    return _canon['reward']


@atexit.register
def _canon_flush():
    if not _canon:
        return
    try:
        os.makedirs(os.path.dirname(REWARD_JSON), exist_ok=True)
        with open(REWARD_JSON, 'w') as fh:
            json.dump(_canon, fh, indent=2)
        # reward.txt too: harbor prefers reward.json, but the sandbox teardown script and
        # the lighthouse UI read reward.txt. Writing both from one dict means they cannot
        # disagree.
        with open(REWARD_TXT, 'w') as fh:
            fh.write(str(_canon['reward']))
    except Exception as exc:
        print('WARNING: could not write %s: %s' % (REWARD_JSON, exc), file=sys.stderr)


def rubric_verdict(argv):
    """The verdict test.sh hands in as `--rubric pass|fail|""`.

    Anything that is not an explicit pass/fail — including the empty string — means "not
    graded", which must never penalise the run.
    """
    if '--rubric' not in argv:
        return None
    i = argv.index('--rubric')
    value = argv[i + 1].strip().lower() if i + 1 < len(argv) else ''
    return value if value in ('pass', 'fail') else None


def load_results():
    """Return {test_identifier: 'pass'|'fail'|'skip'} parsed from the JUnit report."""
    results = {}
    if not os.path.exists(REPORT):
        return results
    tree = ET.parse(REPORT)
    for tc in tree.iter('testcase'):
        classname = tc.get('classname', '')
        name = tc.get('name', '')
        # pytest junitxml classname is dotted module path; identifiers in config.json are
        # "path/to/file.py::test_name" -- match tolerantly against both forms below.
        full = f"{classname}::{name}".strip(':')
        failed = any(c.tag in ('failure', 'error') for c in tc)
        skipped = any(c.tag == 'skipped' for c in tc)
        results[full] = 'skip' if skipped else ('fail' if failed else 'pass')
    return results


def matched(idents, results):
    """Match each configured identifier against reported test names (substring tolerant,
    since junitxml classnames use dotted module paths, e.g. tests.snapshot_tests.test_snapshots)."""
    out = {}
    for ident in idents:
        test_name = ident.split('::')[-1]
        hit = None
        for k, v in results.items():
            if ident in k or k.endswith(f"::{test_name}") or re.search(re.escape(test_name), k):
                hit = v
                break
        out[ident] = hit or 'missing'
    return out


def main():
    results = load_results()
    f2p = matched(F2P, results)
    p2p = matched(P2P, results)
    reward = canon_reward(f2p, p2p, rubric_verdict(sys.argv[1:]))

    print(json.dumps({'reward': reward, 'f2p': f2p, 'p2p': p2p}))


if __name__ == '__main__':
    main()
