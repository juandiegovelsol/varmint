#!/usr/bin/env bash
# =============================================================================
# Behavioural verifier for fossasia__eventyay-3832-mm.
#
# eventyay-specific bits that EVERY task from this repo needs (keep them when
# retargeting this harness at another eventyay candidate):
#   * the python project root is /app/app, not /app  -> `cd /app/app` for pytest
#   * eventyay has no sqlite fallback                -> `harbor_pg_start` first
#     (the helper is baked into the image; it starts the in-image PostgreSQL
#     cluster over loopback, which needs no network)
#   * NOTHING is installed here — the verify run is OFFLINE.
#
# ONE DEVIATION FROM THE eventyay DONOR, forced by this base commit: app/
# pyproject.toml spells the pytest table `[tool.pytest]` instead of
# `[tool.pytest.ini_options]`, so pytest reads NO ini options from it and
# DJANGO_SETTINGS_MODULE is never set.  The settings module named in that
# (ignored) table is passed explicitly with --ds; nothing else about the
# environment is overridden.  --no-migrations builds the schema with
# --run-syncdb, which is why the image pre-creates the postgres extensions in
# template1.
#
# The suite is run, never grepped: no source file is inspected for the fix.
# =============================================================================
set -uo pipefail

mkdir -p /logs/verifier
STDOUT_LOG=/logs/verifier/test-stdout.txt
STDERR_LOG=/logs/verifier/test-stderr.txt
REPORT=/logs/verifier/report.xml

: > "$STDOUT_LOG"
: > "$STDERR_LOG"

ensure_reward() { [ -f /logs/verifier/reward.txt ] || echo 0 > /logs/verifier/reward.txt; }
trap ensure_reward EXIT

cd /app || { echo "no /app" | tee -a "$STDERR_LOG"; exit 1; }

# Capture the agent's submission BEFORE anything below mutates /app -- this is the last
# moment the tree is base + agent work; the restore loop and test.patch come next.
#
# A THROWAWAY INDEX, never /app/.git/index: `git add` against the real one would leave paths
# staged and change how the `git checkout harbor_base --` and `git clean` below behave.
#
# TRACKED EDITS + A SOURCE WHITELIST, not `add -A` with a blacklist. This image installs the
# full dependency set in-tree AFTER the harbor_base commit (environment/Dockerfile) -- the venv,
# compiled translations (manage.py compilemessages) and the postgres cluster all land under /app,
# and none of it is in .gitignore since harbor_base was committed before those steps ran. A bare
# `add -A` would capture all of that as "agent work". Inverting it -- stage tracked modifications,
# then add only untracked files that LOOK like source -- keeps the agent's work and drops
# generated/installed output by default.
_SUB=/logs/verifier/submission.patch
_SUBIDX=/tmp/.submission_index
_SUBSRC=('*.c' '*.cc' '*.cpp' '*.cxx' '*.h' '*.hh' '*.hpp' '*.hxx' '*.inl' '*.m' '*.mm'
         '*.py' '*.rb' '*.go' '*.rs' '*.java' '*.js' '*.ts' '*.tsx' '*.cs' '*.kt' '*.swift')
rm -f "$_SUBIDX"
GIT_INDEX_FILE="$_SUBIDX" git -C /app read-tree harbor_base 2>>"$STDERR_LOG" || true
GIT_INDEX_FILE="$_SUBIDX" git -C /app add -u 2>>"$STDERR_LOG" || true
# Enumerate before adding: `git add` aborts and stages NOTHING if any one pathspec matches
# no file, which silently drops the agent's new files on most tasks.
# Generated-output dirs are dropped from the UNTRACKED scan only. A project that keeps real
# source under lib/ is unaffected: those files are tracked at harbor_base, so `add -u` above
# already has them. This drops only files CREATED under a build dir during the run -- which,
# left in, break replay: they are recorded as new-file hunks and a fresh container from the
# same image already has them, so `git apply` fails with "already exists in working directory".
mapfile -t _SUBNEW < <(git -C /app ls-files --others --exclude-standard \
  -- "${_SUBSRC[@]}" ':(exclude)lib/' ':(exclude)build/' ':(exclude).deps/' 2>/dev/null)
if [ "${#_SUBNEW[@]}" -gt 0 ]; then
  GIT_INDEX_FILE="$_SUBIDX" git -C /app add -- "${_SUBNEW[@]}" 2>>"$STDERR_LOG" || true
fi
GIT_INDEX_FILE="$_SUBIDX" git -C /app diff --binary --cached harbor_base \
  > "$_SUB" 2>>"$STDERR_LOG" || true
rm -f "$_SUBIDX"

# WHAT THE WHITELIST DROPPED, listed rather than silently discarded. The split above captures
# every change to a TRACKED file (any extension, deletions included) but only NEW files that
# look like source -- so an agent adding config.yml, a .cmake module or an extensionless script
# loses it, and the patch still looks clean. That is the failure this manifest exists to expose.
#
# NEWEST FIRST, which is the useful ordering and not a cosmetic one: build output and image
# assets are created before the agent phase starts, so anything the agent made sorts to the top.
# Build artifacts are excluded by the same rules as the capture, to keep the list readable.
#
# If something here belongs in the submission, widen _SUBSRC. Do not reach for `add -A`.
_SUBSKIP=/logs/verifier/submission-skipped.txt
_SUBCAP=/tmp/.submission_captured
if [ "${#_SUBNEW[@]}" -gt 0 ]; then printf '%s\n' "${_SUBNEW[@]}" > "$_SUBCAP"; else : > "$_SUBCAP"; fi
_SUBSKIPN=$(git -C /app ls-files --others --exclude-standard -- . \
    ':(exclude)lib/' ':(exclude)build/' ':(exclude).deps/' \
    ':(exclude)*.o' ':(exclude)*.d' ':(exclude)*.a' ':(exclude)*.lo' ':(exclude)*.la' \
    ':(exclude)*.so' ':(exclude)*.so.*' ':(exclude)*.gch' ':(exclude)*.pyc' 2>/dev/null \
  | grep -vxF -f "$_SUBCAP" 2>/dev/null | wc -l)
{ echo "# Untracked files NOT captured into submission.patch, newest first."
  echo "# Anything the agent created sorts above build output, which predates the agent phase."
  echo "# total: ${_SUBSKIPN}  (showing at most 40)"
  git -C /app ls-files --others --exclude-standard -- . \
      ':(exclude)lib/' ':(exclude)build/' ':(exclude).deps/' \
      ':(exclude)*.o' ':(exclude)*.d' ':(exclude)*.a' ':(exclude)*.lo' ':(exclude)*.la' \
      ':(exclude)*.so' ':(exclude)*.so.*' ':(exclude)*.gch' ':(exclude)*.pyc' 2>/dev/null \
    | grep -vxF -f "$_SUBCAP" 2>/dev/null | head -200 \
    | while IFS= read -r _f; do
        printf '%s\t%s\t%s\n' "$(stat -c %Y "/app/$_f" 2>/dev/null || echo 0)" \
                              "$(stat -c %s "/app/$_f" 2>/dev/null || echo 0)" "$_f"
      done \
    | sort -rn | head -40 | awk -F'\t' '{printf "%s\t%s\t%s\n",$1,$2,$3}'
} > "$_SUBSKIP" 2>/dev/null || true
rm -f "$_SUBCAP"

# Size guard. The whitelist is a heuristic, so a task laying out source unusually could still
# produce something enormous. Cap it and leave a diagnosable stub: a truncated capture is
# recoverable, a full disk is not.
_SUBSZ=$(wc -c < "$_SUB" 2>/dev/null || echo 0)
if [ "$_SUBSZ" -gt 5242880 ]; then
  { echo "SUBMISSION CAPTURE SUPPRESSED: ${_SUBSZ} bytes exceeds the 5MB cap."
    echo "Directories contributing to the discarded patch:"
    grep -a "^diff --git" "$_SUB" | sed 's#^diff --git a/##; s# b/.*##; s#/[^/]*$##' \
      | sort | uniq -c | sort -rn | head -20
  } > "$_SUB.suppressed" 2>/dev/null
  : > "$_SUB"
  echo "== submission.patch SUPPRESSED (${_SUBSZ} bytes > 5MB cap) ==" | tee -a "$STDOUT_LOG"
else
  echo "== captured submission.patch (${_SUBSZ} bytes, $(grep -ac '^diff --git' "$_SUB" 2>/dev/null || echo 0) files) ==" \
    | tee -a "$STDOUT_LOG"
fi


# ── Robustness + idempotency ──────────────────────────────────────────────────
# 1. Restore EVERY path test.patch touches to the pristine harbor_base state, so
#    agent edits to test files cannot affect scoring and the apply is idempotent.
#    Paths come from the `diff --git a/... b/...` headers, which exist for every
#    entry type (text, binary, rename, delete) unlike `+++ b/`.
# 2. Additionally restore the whole test tree, which is where any PRE-EXISTING
#    test scored as p2p would live — those are not named in test.patch and would
#    otherwise be tamperable.
# 3. Clean ONLY the directories named by the patch. A bare `git clean -fdq -- .`
#    would wipe /app/.harbor_assets and the agent's own new files.
_patch_paths=$(
  { sed -n 's#^diff --git a/\(.*\) b/.*#\1#p' /tests/test.patch
    sed -n 's#^diff --git a/.* b/\(.*\)#\1#p' /tests/test.patch
  } | sort -u
)
for _p in $_patch_paths; do
  git -C /app checkout harbor_base -- "$_p" 2>/dev/null \
    || rm -f "/app/$_p" 2>/dev/null \
    || true
done
git -C /app checkout harbor_base -- app/tests 2>/dev/null || true
git -C /app clean -fdq -- $(printf '%s\n' $_patch_paths | xargs -r -n1 dirname | sort -u) 2>/dev/null || true

echo "== applying test.patch ==" | tee -a "$STDOUT_LOG"
git apply --binary /tests/test.patch 2>>"$STDERR_LOG" \
  || git apply /tests/test.patch 2>>"$STDERR_LOG" \
  || patch -p1 -i /tests/test.patch 2>>"$STDERR_LOG" \
  || { echo "ERROR: could not apply test.patch" | tee -a "$STDERR_LOG"; exit 1; }

# ── Test-only frontend/browser tooling ──────────────────────────────────────────
# tests/e2e/ drives a real browser against the actual video SPA -- something eventyay
# itself never needs to run. Node, Redis, Playwright/Chromium and the webapp's
# node_modules are installed HERE, at verify time, rather than baked into the image:
# none of it is needed to run eventyay, only to grade this task's browser check.
# Versions are pinned so a rebuild cannot silently resolve a different chromium/
# protocol pairing. Requires network -- [verifier] network_mode = "public" permits it.
echo "== installing test-only frontend/browser tooling ==" | tee -a "$STDOUT_LOG"
{ apt-get update && apt-get install -y --no-install-recommends nodejs npm redis-server \
    && rm -rf /var/lib/apt/lists/* \
    && ( cd /app/app/eventyay/webapp/video && npm ci ) \
    && ( cd /app/app \
         && uv pip install playwright==1.62.0 pytest-playwright==0.9.0 \
         && uv run playwright install --with-deps chromium ); } \
  >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || { echo "ERROR: frontend/browser tooling install failed" | tee -a "$STDERR_LOG"; exit 1; }

# ── Build the video SPA from whatever is in /app right now ────────────────────
# node_modules is pre-installed at image build time (package.json/-lock.json never change
# per-submission), but the BUILD itself has to happen here: it compiles the candidate's own
# UploadUrlInput.vue/api.js/config.js, which do not exist until the agent's (or oracle's/
# nop's) submission is already in place. Building at image time would freeze in the pre-fix
# bundle forever, and tests/e2e/ would silently exercise stale JS no matter what a submission
# changes. OUT_DIR is the project's own build-output override (webapp/video/vite.config.js).
# BASE_DIR (eventyay/config/settings.py) is the eventyay PACKAGE dir, i.e. /app/app/eventyay.
echo "== building the video SPA ==" | tee -a "$STDOUT_LOG"
( cd /app/app/eventyay/webapp/video \
  && rm -rf /app/app/eventyay/static.dist \
  && OUT_DIR=/app/app/eventyay/static.dist npx vite build --mode production ) \
  >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  && test -f /app/app/eventyay/static.dist/video/index.html \
  || { echo "ERROR: video SPA build failed or produced no index.html" | tee -a "$STDERR_LOG"; exit 1; }

# ── Database ──────────────────────────────────────────────────────────────────
# eventyay only supports PostgreSQL (django.contrib.postgres / JSONB / ARRAY).
# The cluster and the `pretix` database were created at IMAGE BUILD time; this
# only starts the server on 127.0.0.1:5432. Offline.
echo "== starting in-image postgres ==" | tee -a "$STDOUT_LOG"
harbor_pg_start >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || { echo "ERROR: postgres unavailable" | tee -a "$STDERR_LOG"; exit 1; }

# ── Redis ──────────────────────────────────────────────────────────────────────
# tests/e2e/ drives a real browser against the actual video SPA, which needs its
# realtime layer (django-channels, hardcoded to channels_redis -- no in-memory
# fallback) actually working. Installed and started the same way as postgres above.
echo "== starting in-image redis ==" | tee -a "$STDOUT_LOG"
harbor_redis_start >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || { echo "ERROR: redis unavailable" | tee -a "$STDERR_LOG"; exit 1; }

# ── Test-only deps ────────────────────────────────────────────────────────────
# pytest / pytest-django / pytest-env / playwright and the full application dependency
# set are BAKED at image build time (`uv sync --frozen --all-extras --group test`, plus
# `uv pip install playwright pytest-playwright` and the chromium binary it needs).
echo "== checking pinned test deps (no install) ==" | tee -a "$STDOUT_LOG"
python -c "import pytest, django, pytest_django, playwright; print('pytest', pytest.__version__, '| django', django.get_version())" \
  | tee -a "$STDOUT_LOG"

# ── Run f2p + p2p tests ───────────────────────────────────────────────────────
# Only the suites added by test.patch are run; together they hold every f2p and every
# p2p. `-p no:cacheprovider` keeps /app free of .pytest_cache, `-p no:sugar` /
# `-p no:xdist` keep the JUnit report deterministic and machine-readable.
# DJANGO_ALLOW_ASYNC_UNSAFE is required by tests/e2e/: ChannelsLiveServerTestCase's ORM
# fixture setup runs in a thread asgiref's sync/async bridging marks as async-tainted,
# even though the code itself is synchronous -- this is Django's own documented escape
# hatch for that shape of false positive, not a relaxation of real async-safety.
cd /app/app || { echo "no /app/app" | tee -a "$STDERR_LOG"; exit 1; }

run_suite() {
  DJANGO_ALLOW_ASYNC_UNSAFE=1 python -m pytest \
    "tests/video_upload_limit/test_video_upload_size_contract.py" \
    "tests/e2e/test_upload_error_ui.py" \
    --ds=eventyay.config.settings --no-migrations \
    -p no:cacheprovider -p no:sugar -p no:xdist \
    -q --junitxml="$REPORT" \
    >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
    || echo "(tests exited non-zero; parsing report)" | tee -a "$STDOUT_LOG"
}

report_has_testcases() {
  python3 - "$REPORT" <<'PY'
import sys, os, xml.etree.ElementTree as ET
path = sys.argv[1]
if not os.path.exists(path):
    sys.exit(1)
try:
    tree = ET.parse(path)
except Exception:
    sys.exit(1)
sys.exit(0 if next(tree.iter('testcase'), None) is not None else 1)
PY
}

echo "== running f2p + p2p tests ==" | tee -a "$STDOUT_LOG"
run_suite

# One-shot retry ONLY when the report is missing or carries ZERO <testcase>
# elements — i.e. the runner crashed or collection aborted before any test was
# recorded, which would otherwise be scored as a false 0.0. A report full of
# FAILURES is a real verdict and is never retried.
if ! report_has_testcases; then
  echo "== JUnit report has no testcases; retrying the suite once ==" | tee -a "$STDOUT_LOG"
  rm -f "$REPORT"
  run_suite
  report_has_testcases \
    && echo "== retry produced a populated report ==" | tee -a "$STDOUT_LOG" \
    || echo "== retry still produced no testcases ==" | tee -a "$STDERR_LOG"
fi

# ── Compute reward ────────────────────────────────────────────────────────────
echo "== computing reward ==" | tee -a "$STDOUT_LOG"
# This task ships no rubric layer (Mode B): the behavioural suite covers the whole defect,
# so there is no tests/rubrics.json and no tests/judge.py. RUBRIC is therefore always the
# empty string, which verifier.py reads as "not graded" -> rubric_passed = -1. The flag is
# passed anyway so the verifier call has the same shape as on a rubric task; an empty
# verdict can never lower the reward.
RUBRIC=""

# Rubric judge — SUB-AGENT backend: no API key, no network. On the first pass there is no
# verdict yet, so judge.py writes a judge request under /logs/verifier/judge/ and prints
# nothing; scoring falls back to tests alone. Once a judge sub-agent has written
# verdict.json there, `mm_run.sh <task> rescore` folds the verdict into the reward.
# The `|| echo ""` is load-bearing: the judge must never be able to fail the run.
RUBRIC=""
if [ -f /tests/rubrics.json ]; then
  RUBRIC=$(python3 /tests/judge.py --rubrics /tests/rubrics.json --repo /app \
             2>/logs/verifier/judge.log || echo "")
  echo "Rubric verdict: ${RUBRIC:-pending (judge request written; rescore after grading)}"
fi

python3 /tests/verifier.py --rubric "${RUBRIC:-}"

echo "reward=$(cat /logs/verifier/reward.txt 2>/dev/null)" | tee -a "$STDOUT_LOG"
