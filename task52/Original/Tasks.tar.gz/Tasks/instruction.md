# A row of blocks does not keep the look it had on first draw

A short horizontal row of three labeled blocks is on screen.

On first draw it looks like this:

![first draw](/app/.harbor_assets/bug_screenshot_1.png)

After the window is no longer in the foreground, and still after it is in the foreground again, it looks like this instead:

![after leaving and returning](/app/.harbor_assets/bug_screenshot_2.png)

The three labels and their order are unchanged. The difference is only in how one of the blocks is drawn, and that first-draw look does not come back on its own.

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png`
- `/app/.harbor_assets/bug_screenshot_2.png`

These images are available inside the container and are part of the report; compare them before making changes.
