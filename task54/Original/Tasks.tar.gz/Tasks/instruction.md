# Something is missing from the device settings page after I backed out of a dialog

I opened a dialog from the device settings page, got part of the way through it, and then closed it
with the X in the corner instead of carrying on to the end.

When I landed back on the settings page, it was no longer showing me everything it had been showing
before. Something that used to be there is just gone, and it stays gone for as long as the device
is connected in this state — nothing I do on that page brings it back.

It is not only my own device either. A colleague whose device was set up differently from mine ends
up at the same dead end, so this does not look like something particular to my one machine. Please
make sure it works for the device in the recording as well as for theirs.

The recording below is what happened. The two stills are frames pulled out of it: the first is the
dialog at the moment I closed it, the second is the settings page afterwards.

- `/app/.harbor_assets/bug_screenshot_0.mov`
- `/app/.harbor_assets/bug_screenshot_1.png`
- `/app/.harbor_assets/bug_screenshot_2.png`

<img width="1600" height="882" src="/app/.harbor_assets/bug_screenshot_1.png" />

<img width="1600" height="882" src="/app/.harbor_assets/bug_screenshot_2.png" />

The screenshots show what I ended up with. I have not written out what is in them, because they
are the only record of it — see the attached files, which ship inside the container, and open them
before making any changes.
