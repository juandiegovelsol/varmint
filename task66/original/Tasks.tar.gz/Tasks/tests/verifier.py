#!/usr/bin/env python3
"""
Verifier for radix-ui__primitives-2049-mm (Select overflow positioning).
Synthetic test — authored in Step 1b per spec.
Parses jest --json output (not JUnit XML, since this base uses jest@27).

Reward policy:
  1.0 — every f2p passes AND every p2p passes AND the rubric verdict is not "fail".
  0.5 — a strict subset of f2p passes, or every f2p passes but a p2p regression guard
        fails, or all f2p+p2p pass but the rubric verdict is "fail".
  0.0 — no f2p passes, or the suite failed to run.
"""
import argparse
import json
import os
import re
import sys

CONF = json.load(open('/tests/config.json'))
F2P, P2P = CONF['f2p'], CONF['p2p']
REPORT = '/logs/verifier/report.json'
REWARD = '/logs/verifier/reward.txt'
REWARD_JSON = '/logs/verifier/reward.json'


def load_results():
    """Return {test_identifier: 'pass'|'fail'|'skip'} parsed from jest --json output."""
    results = {}
    if not os.path.exists(REPORT):
        return results
    try:
        data = json.load(open(REPORT))
    except (json.JSONDecodeError, IOError) as e:
        print(f"JSON parse error: {e}", file=sys.stderr)
        return results

    # Jest JSON format: { testResults: [ { name, assertionResults: [ {fullName, status} ] } ] }
    # Note: jest uses 'assertionResults' (not 'testResults') for individual tests within a suite.
    for suite in data.get('testResults', []):
        for tc in suite.get('assertionResults', suite.get('testResults', [])):
            name = tc.get('fullName', tc.get('title', ''))
            status_raw = tc.get('status', 'unknown')
            # Jest statuses: 'passed', 'failed', 'pending', 'skipped', 'todo'
            if status_raw == 'passed':
                status = 'pass'
            elif status_raw in ('pending', 'skipped', 'todo'):
                status = 'skip'
            else:
                status = 'fail'
            results[name] = status
    return results


def matched(idents, results):
    """Match each identifier against reported test names (substring/regex tolerant)."""
    out = {}
    for ident in idents:
        hit = next(
            (v for k, v in results.items()
             if ident in k or re.search(re.escape(ident), k)),
            None
        )
        out[ident] = hit or 'missing'
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rubric', default='', help='"pass", "fail", or "" (no verdict yet)')
    args = ap.parse_args()

    r = load_results()
    f2p_matched = matched(F2P, r)
    p2p_matched = matched(P2P, r)

    f2p_pass = [k for k, v in f2p_matched.items() if v == 'pass']
    p2p_pass = [k for k, v in p2p_matched.items() if v == 'pass']

    all_f2p = len(f2p_pass) == len(F2P) and len(F2P) > 0
    all_p2p = len(p2p_pass) == len(P2P)  # vacuously true when P2P=[]
    rubric_failed = args.rubric.strip() == 'fail'

    if all_f2p and all_p2p and not rubric_failed:
        reward = 1.0
    elif all_f2p and all_p2p and rubric_failed:
        # Tests are clean but the rubric caught an approach defect: never drop all the
        # way to 0.0 for a rubric-only failure, but do not award full credit either.
        reward = 0.5
    elif f2p_pass:
        reward = 0.5
    else:
        reward = 0.0

    os.makedirs(os.path.dirname(REWARD), exist_ok=True)
    open(REWARD, 'w').write(str(reward))

    # reward.json MUST be a FLAT map of numbers: harbor parses it as
    # VerifierResult.rewards: dict[str, float] and prefers it over reward.txt, so a
    # nested dict/string/None here raises a pydantic ValidationError that aborts the
    # trial before any reward is recorded, even though reward.txt was written correctly.
    # Per-test outcomes therefore ride along as flat f2p::<name> / p2p::<name> entries,
    # and the rubric verdict as rubric_pass = 1 pass / 0 fail / -1 unavailable.
    detail = {'reward': reward}
    for name, status in f2p_matched.items():
        detail[f'f2p::{name}'] = 1.0 if status == 'pass' else 0.0
    for name, status in p2p_matched.items():
        detail[f'p2p::{name}'] = 1.0 if status == 'pass' else 0.0
    rubric_verdict = args.rubric.strip()
    detail['rubric_graded'] = 1.0 if rubric_verdict in ('pass', 'fail') else 0.0
    detail['rubric'] = 1.0 if rubric_verdict == 'pass' else 0.0
    json.dump(detail, open(REWARD_JSON, 'w'), indent=2)
    print(json.dumps({'reward': reward, 'f2p': f2p_matched, 'p2p': p2p_matched,
                       'rubric': args.rubric or 'pending'}))


if __name__ == '__main__':
    main()
