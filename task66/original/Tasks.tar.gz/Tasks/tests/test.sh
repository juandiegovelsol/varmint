#!/usr/bin/env bash
# Behavioral verifier for radix-ui__primitives-2049-mm (SYNTHETIC).
# Synthetic test for Select content horizontal overflow positioning.
# NEVER greps source for the fix — it runs the tests.
set -uo pipefail
mkdir -p /logs/verifier
STDOUT_LOG=/logs/verifier/test-stdout.txt
STDERR_LOG=/logs/verifier/test-stderr.txt
REPORT=/logs/verifier/report.json
: > "$STDOUT_LOG"; : > "$STDERR_LOG"

ensure_reward() { [ -f /logs/verifier/reward.txt ] || echo 0 > /logs/verifier/reward.txt; }
trap ensure_reward EXIT

cd /app || { echo "no /app" | tee -a "$STDERR_LOG"; exit 1; }

# Restore any test paths the agent may have edited to their pristine base state
# before applying test.patch, so agent edits to tests cannot change scoring.
# Paths are read from the `diff --git a/... b/...` headers rather than from `+++ b/`
# lines, so binary/rename hunks (which have no `+++ b/` line) are reset too.
_patch_paths=$( { sed -n 's#^diff --git a/\(.*\) b/.*#\1#p' /tests/test.patch
                  sed -n 's#^diff --git a/.* b/\(.*\)#\1#p' /tests/test.patch; } | sort -u )
for _p in $_patch_paths; do
  git -C /app checkout harbor_base -- "$_p" 2>/dev/null || rm -f "/app/$_p" 2>/dev/null || true
done

echo "== applying test.patch ==" | tee -a "$STDOUT_LOG"
git apply --binary /tests/test.patch 2>>"$STDERR_LOG" \
  || git apply /tests/test.patch 2>>"$STDERR_LOG" \
  || patch -p1 -i /tests/test.patch 2>>"$STDERR_LOG" \
  || { echo "ERROR: could not apply test.patch" | tee -a "$STDERR_LOG"; exit 1; }

echo "== installing pinned test-only deps ==" | tee -a "$STDOUT_LOG"
# No extra test-only deps needed; yarn install was done in the Dockerfile.

echo "== fixing jest moduleNameMapper ==" | tee -a "$STDOUT_LOG"
# The jest.moduleNameMapper at this base commit has a bug: '@radix-ui/(.+)$' maps to
# '<rootDir>packages/core/$1/src' (missing leading '/'), which resolves to a non-existent
# path and breaks @radix-ui/number, @radix-ui/primitive, @radix-ui/rect imports.
# Fix it in-place so the test can run; this does not affect source or patch application.
python3 - << 'PYEOF' | tee -a "$STDOUT_LOG"
import json, sys

path = '/app/package.json'
with open(path) as f:
    config = json.load(f)

mapper = config.get('jest', {}).get('moduleNameMapper', {})
old_val = mapper.get('@radix-ui/(.+)$', '')
if old_val and not old_val.startswith('<rootDir>/'):
    # Fix: ensure the path starts with <rootDir>/
    fixed = old_val.replace('<rootDir>', '<rootDir>/', 1)
    mapper['@radix-ui/(.+)$'] = fixed
    with open(path, 'w') as f:
        json.dump(config, f, indent=2)
    print(f'Fixed moduleNameMapper: {old_val!r} -> {fixed!r}')
else:
    print(f'moduleNameMapper looks correct: {old_val!r}')
PYEOF

echo "== running f2p + p2p tests ==" | tee -a "$STDOUT_LOG"
# This base commit uses yarn@4.1.0 + jest@27. Use JSON reporter for report parsing.
yarn jest \
  --json \
  --outputFile="$REPORT" \
  packages/react/select/src/select.test.tsx \
  >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || echo "(jest exited non-zero; parsing report)" | tee -a "$STDOUT_LOG"

echo "== running rubric judge ==" | tee -a "$STDOUT_LOG"
# Rubric judge — sub-agent backend, no API key, no network (see tests/judge.py).
RUBRIC=""
if [ -f /tests/rubrics.json ]; then
  RUBRIC=$(python3 /tests/judge.py --rubrics /tests/rubrics.json --repo /app \
             2>/logs/verifier/judge.log || echo "")
  echo "Rubric verdict: ${RUBRIC:-pending (judge request written; rescore after grading)}" | tee -a "$STDOUT_LOG"
fi

echo "== computing reward ==" | tee -a "$STDOUT_LOG"
python3 /tests/verifier.py --rubric "${RUBRIC:-}" 2>>"$STDERR_LOG" | tee -a "$STDOUT_LOG"
echo "reward=$(cat /logs/verifier/reward.txt 2>/dev/null)" | tee -a "$STDOUT_LOG"
