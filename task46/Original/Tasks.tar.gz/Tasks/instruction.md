### Description

The two screenshots below come from the exact same wxWidgets sample app and the exact same paint-event code. The only difference between the two runs is which one of two equivalent techniques the paint handler uses to remap its on-screen drawing coordinates before it paints.

![wxGTK_run_A](/app/.harbor_assets/bug.png)

![wxGTK_run_B](/app/.harbor_assets/after.png)

With one of the two techniques, the window renders as shown in the first screenshot. With the other, it renders as shown in the second. Find the bug responsible for the difference and fix it so that the window renders the same correct way (as in the second screenshot) regardless of which of the two techniques the paint handler uses.
