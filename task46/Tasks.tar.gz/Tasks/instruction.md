### Description

The two screenshots below come from the same wxWidgets sample app. The drawing calls themselves are unchanged between the two runs -- something about how the paint handler sets things up before it draws is different.

![wxGTK_run_A](/app/.harbor_assets/run_a.png)

![wxGTK_run_B](/app/.harbor_assets/run_b.png)

With one setup, the window renders as shown in the first screenshot. With the other, it renders as shown in the second. Find the bug responsible for the difference and fix it so the window renders the same correct way as in the second screenshot.
