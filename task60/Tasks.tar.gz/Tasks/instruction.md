Page has this weird zoom effect where it makes the scrollbar not do anything and it hides information

First pic is issue, second pic is zoomed out to be able to see what it should kind of look like

Happens on more than one of the history pages, they all look like this

![image](/app/.harbor_assets/bug.png)
![image](/app/.harbor_assets/bug_zoomed_out.png)
