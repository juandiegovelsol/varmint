<?php
// Deterministic DB seeding for the jwtHistory.php / base64history.php behavioral verifier.
// Both pages carry the same unbounded-table defect, so both need a row whose cells hold one
// long unbroken string. Uses the app's own
// Database class + real password_hash()/PDO -- no source-string inspection, just data setup
// so the login form and the history query have something real to exercise.
putenv("DB_HOST=localhost");
putenv("DB_USER=root");
putenv("DB_PASSWORD=");
putenv("DB_NAME=consolidev");

require_once "/app/Database.php";

$username = getenv('SEED_USERNAME') ?: 'verifieruser';
$password = getenv('SEED_PASSWORD') ?: 'TestPass123!';

$db = new Database(getenv('DB_HOST'), getenv('DB_NAME'), getenv('DB_USER'), getenv('DB_PASSWORD'));
$conn = $db->getConnection();

// Reset any prior run's rows for this user so re-verification stays idempotent.
$stmt = $conn->prepare("DELETE FROM jwt WHERE username = :u");
$stmt->execute([':u' => $username]);
$stmt = $conn->prepare("DELETE FROM base64 WHERE username = :u");
$stmt->execute([':u' => $username]);
$stmt = $conn->prepare("DELETE FROM user WHERE username = :u");
$stmt->execute([':u' => $username]);

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare(
    "INSERT INTO user (username, Fname, Lname, password, DateJoined) VALUES (:u, 'Ver', 'User', :p, CURDATE())"
);
$stmt->execute([':u' => $username, ':p' => $hash]);

// One long, unbroken (no spaces/hyphens) JWT-like token in each column -- mirrors the
// screenshot's real defect (a single giant token with no wrap points).
$encoded = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' . str_repeat('A', 420) . '.' . str_repeat('B', 120);
$decoded = json_encode(str_repeat('x', 480));

$stmt = $conn->prepare(
    "INSERT INTO jwt (username, date, encoded, decoded) VALUES (:u, CURDATE(), :e, :d)"
);
$stmt->execute([':u' => $username, ':e' => $encoded, ':d' => $decoded]);

// The same shape for base64history.php. That table is three columns (type / original /
// opposite) rather than two, and `type` is varchar(6), so the long strings go in the two
// text columns. A base64 body has no spaces or hyphens either, so it has no wrap points --
// which is the property that blows out the layout.
$b64_original = str_repeat('QUJDREVG', 60);                       // 480 chars, unbroken
$b64_opposite = base64_encode(str_repeat('consolidev-payload', 26));
$stmt = $conn->prepare(
    "INSERT INTO base64 (username, date, type, original, opposite) VALUES (:u, CURDATE(), 'encode', :o, :p)"
);
$stmt->execute([':u' => $username, ':o' => $b64_original, ':p' => $b64_opposite]);

echo "seeded user={$username} jwt-row encoded-len=" . strlen($encoded) . " decoded-len=" . strlen($decoded)
    . " base64-row original-len=" . strlen($b64_original) . " opposite-len=" . strlen($b64_opposite) . "\n";
