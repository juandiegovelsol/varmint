#!/usr/bin/env python3
import argparse
import atexit
import json
import os
import sys

CONF = json.load(open('/tests/config.json'))
F2P = CONF['f2p']
P2P = CONF['p2p']
REPORT = '/logs/verifier/measure.json'

_CANON_JSON = "/logs/verifier/reward.json"
_CANON_TXT = "/logs/verifier/reward.txt"
_canon = {}

def canon_reward(f2p_passed, f2p_total, p2p_passed, p2p_total, rubric,
                 f2p_detail=None, p2p_detail=None):
    f, t = int(f2p_passed), int(f2p_total)
    p, q = int(p2p_passed), int(p2p_total)
    solved = bool(t) and f == t and p == q
    tests_passed = 1.0 if solved else 0.0
    _canon.clear()
    _canon.update({
        "reward": 0.0 if rubric == "fail" else tests_passed,
        "tests_passed": tests_passed,
        "f2p_passed": f, "f2p_total": t,
        "p2p_passed": p, "p2p_total": q,
        "rubric_passed": {"pass": 1, "fail": 0}.get(rubric, -1),
    })
    # Per-test outcomes, alongside the canonical seven (QC strips `::` keys before validating
    # the schema, so these are an expected extra rather than a violation).
    #
    # The aggregate counts cannot say WHICH test passed, so an f2p test that also passes on an
    # empty submission -- an inert test that can never detect the bug -- is invisible in
    # f2p_passed/f2p_total. QC reads these off the Nop run to catch exactly that. With a single
    # f2p test the aggregate happens to be equivalent; with more than one it is not.
    for prefix, detail in (("f2p", f2p_detail or {}), ("p2p", p2p_detail or {})):
        for ident, outcome in detail.items():
            _canon["%s::%s" % (prefix, ident)] = 1.0 if outcome == "pass" else 0.0
    return _canon["reward"]

@atexit.register
def _canon_flush():
    if not _canon:
        return
    try:
        os.makedirs(os.path.dirname(_CANON_JSON), exist_ok=True)
        with open(_CANON_JSON, "w") as _h:
            json.dump(_canon, _h, indent=2)
        with open(_CANON_TXT, "w") as _h:
            _h.write(str(_canon["reward"]))
    except Exception as _exc:
        print("WARNING: could not write %s: %s" % (_CANON_JSON, _exc), file=sys.stderr)

def load_results():
    if not os.path.exists(REPORT):
        return {}
    try:
        data = json.load(open(REPORT))
    except Exception:
        return {}
    results = data.get('results', {})
    return {k: ('pass' if v else 'fail') for k, v in results.items()}

def matched(idents, results):
    return {ident: results.get(ident, 'missing') for ident in idents}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rubric', default='', help='"pass" | "fail" | "" (not graded)')
    args = ap.parse_args()
    rubric = (args.rubric or '').strip().lower()
    if rubric not in ('pass', 'fail'):
        rubric = None

    results = load_results()
    f2p = matched(F2P, results)
    p2p = matched(P2P, results)
    f2p_pass = [k for k, v in f2p.items() if v == 'pass']
    p2p_pass = [k for k, v in p2p.items() if v == 'pass']

    reward = canon_reward(len(f2p_pass), len(F2P),
                          len(p2p_pass), len(P2P),
                          rubric,
                          f2p_detail=f2p, p2p_detail=p2p)

    detail = {'reward': reward, 'rubric': rubric, 'f2p': f2p, 'p2p': p2p}
    os.makedirs('/logs/verifier', exist_ok=True)
    with open('/logs/verifier/reward_detail.json', 'w') as f:
        json.dump(detail, f, indent=2)
    print(json.dumps(detail))

if __name__ == '__main__':
    main()
