#!/usr/bin/env bash
set -uo pipefail
mkdir -p /logs/verifier
STDOUT_LOG=/logs/verifier/test-stdout.txt
STDERR_LOG=/logs/verifier/test-stderr.txt
REPORT=/logs/verifier/measure.json
: > "$STDOUT_LOG"; : > "$STDERR_LOG"

ensure_reward() { [ -f /logs/verifier/reward.txt ] || echo 0 > /logs/verifier/reward.txt; }
trap ensure_reward EXIT

cd /app || { echo "no /app" | tee -a "$STDERR_LOG"; exit 1; }

echo "== starting services (mariadb + php) ==" | tee -a "$STDOUT_LOG"
if ! mysqladmin ping --socket=/run/mysqld/mysqld.sock >/dev/null 2>&1; then
  mkdir -p /var/run/mysqld && chown mysql:mysql /var/run/mysqld
  mysqld --user=root --datadir=/var/lib/mysql --socket=/run/mysqld/mysqld.sock &
  for i in $(seq 1 60); do mysqladmin ping --socket=/run/mysqld/mysqld.sock >/dev/null 2>&1 && break; sleep 1; done
fi

# Try ports 18080, 18081, 8099, 8100 to avoid harbor's egress sidecar on 8080
APP_PORT=""
for p in 18080 18081 8099 8100; do
  if ! curl -s -o /dev/null http://127.0.0.1:$p/ 2>/dev/null; then
    php -S 0.0.0.0:$p -t /app >/logs/php.log 2>&1 &
    for i in $(seq 1 30); do
      if curl -fsS -o /dev/null http://127.0.0.1:$p/login.php 2>/dev/null; then
        APP_PORT=$p; break 2
      fi
      sleep 1
    done
  fi
done
if [ -z "$APP_PORT" ]; then
  echo "ERROR: could not start PHP on any port" | tee -a "$STDERR_LOG"; exit 1
fi
echo "PHP serving on port $APP_PORT" | tee -a "$STDOUT_LOG"
export APP_BASE_URL="http://127.0.0.1:$APP_PORT"

echo "== seeding DB ==" | tee -a "$STDOUT_LOG"
export SEED_USERNAME="verifieruser"
export SEED_PASSWORD="TestPass123!"
php /tests/seed.php >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || { echo "ERROR: DB seeding failed" | tee -a "$STDERR_LOG"; exit 1; }

echo "== running headless-browser DOM-geometry measurement ==" | tee -a "$STDOUT_LOG"
NODE_PATH=/opt/verifier-deps/node_modules \
  APP_BASE_URL="$APP_BASE_URL" SEED_USERNAME="$SEED_USERNAME" SEED_PASSWORD="$SEED_PASSWORD" \
  node /tests/measure.js >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || echo "(measure.js exited non-zero; parsing whatever report it wrote)" | tee -a "$STDOUT_LOG"

echo "== rubric judge ==" | tee -a "$STDOUT_LOG"
RUBRIC=""
if [ -f /tests/rubrics.json ]; then
  RUBRIC=$(python3 /tests/judge.py --rubrics /tests/rubrics.json --repo /app 2>/logs/verifier/judge.log || echo "")
fi

echo "== computing reward ==" | tee -a "$STDOUT_LOG"
python3 /tests/verifier.py --rubric "${RUBRIC:-}" 2>>"$STDERR_LOG" | tee -a "$STDOUT_LOG"
echo "reward=$(cat /logs/verifier/reward.txt 2>/dev/null)" | tee -a "$STDOUT_LOG"
