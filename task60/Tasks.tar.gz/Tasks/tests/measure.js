const { chromium } = require('playwright');
const fs = require('fs');

const BASE = process.env.APP_BASE_URL || 'http://127.0.0.1:18080';
const USERNAME = process.env.SEED_USERNAME || 'verifieruser';
const PASSWORD = process.env.SEED_PASSWORD || 'TestPass123!';
const OUT = '/logs/verifier/measure.json';

async function main() {
  const results = {};
  const detail = {};
  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  try {
    const context = await browser.newContext({ viewport: { width: 1280, height: 900 } });
    const page = await context.newPage();

    await page.goto(`${BASE}/login.php`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.fill('#username', USERNAME);
    await page.fill('#password', PASSWORD);
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {}),
      page.click('input[type=submit]'),
    ]);

    await page.goto(`${BASE}/jwtHistory.php`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(300);

    // p2p: seeded row renders
    const rowCount = await page.evaluate(() => {
      const cells = Array.from(document.querySelectorAll('table tr'))
        .filter((tr) => tr.querySelectorAll('td').length >= 2);
      return cells.length;
    });
    results['jwt_history_renders_seeded_row'] = rowCount >= 1;
    detail.rowCount = rowCount;

    // p2p: table headers exist
    const headerCount = await page.evaluate(() => {
      return document.querySelectorAll('table th').length;
    });
    results['jwt_history_has_table_headers'] = headerCount >= 2;
    detail.headerCount = headerCount;

    // f2p: page overflow check
    const geometry = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
    }));
    const ratio = geometry.scrollWidth / geometry.innerWidth;
    detail.geometry = geometry;
    detail.overflowRatio = ratio;
    results['jwt_history_table_bounded_width'] = ratio <= 1.05;

    // Recorded for diagnostics only -- NOT a graded test. A cell-level wrapping threshold was
    // tried as an f2p and rejected: the golden fix bounds the PAGE with a scroll container
    // (display:block + overflow-x:auto) while its cells stay ~6100px wide, so any cell-width
    // gate fails the reference solution. See task.toml's difficulty_explanation.
    const cellWidths = await page.evaluate(() => {
      const tds = Array.from(document.querySelectorAll('table td'));
      return { count: tds.length, widths: tds.map((td) => td.scrollWidth) };
    });
    detail.cellCount = cellWidths.count;
    detail.cellWidths = cellWidths.widths;
    detail.maxCellScrollWidth = cellWidths.count ? Math.max(...cellWidths.widths) : 0;

    // f2p: the same defect on base64history.php. Measured on its own page load so a fix
    // applied only to the page shown in the screenshots does not satisfy it.
    await page.goto(`${BASE}/base64history.php`, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await page.waitForTimeout(300);
    const b64Geometry = await page.evaluate(() => ({
      scrollWidth: document.documentElement.scrollWidth,
      innerWidth: window.innerWidth,
      rowCount: Array.from(document.querySelectorAll('table tr'))
        .filter((tr) => tr.querySelectorAll('td').length >= 2).length,
    }));
    const b64Ratio = b64Geometry.scrollWidth / b64Geometry.innerWidth;
    detail.base64Geometry = b64Geometry;
    detail.base64OverflowRatio = b64Ratio;
    // Guard against a vacuous pass: an empty table cannot overflow, so the seeded row must
    // actually be on the page for the width measurement to mean anything.
    results['base64_history_table_bounded_width'] = b64Geometry.rowCount >= 1 && b64Ratio <= 1.05;

    // Diagnostics only, as above.
    const b64CellWidths = await page.evaluate(() => {
      const tds = Array.from(document.querySelectorAll('table td'));
      return { count: tds.length, widths: tds.map((td) => td.scrollWidth) };
    });
    detail.base64CellCount = b64CellWidths.count;
    detail.base64CellWidths = b64CellWidths.widths;
    detail.base64MaxCellScrollWidth = b64CellWidths.count ? Math.max(...b64CellWidths.widths) : 0;

    await context.close();
  } finally {
    await browser.close();
  }

  fs.mkdirSync('/logs/verifier', { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify({ results, detail }, null, 2));
  console.log(JSON.stringify({ results, detail }));
}

main().catch((err) => {
  console.error('measure.js FAILED:', err && err.stack || err);
  fs.mkdirSync('/logs/verifier', { recursive: true });
  fs.writeFileSync(OUT, JSON.stringify({
    results: {
      jwt_history_renders_seeded_row: false,
      jwt_history_has_table_headers: false,
      jwt_history_table_bounded_width: false,
      base64_history_table_bounded_width: false,
    },
    detail: { error: String(err && err.message || err) },
  }, null, 2));
  process.exit(1);
});
