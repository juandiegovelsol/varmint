# [BUG] A quality/gear effect's dice-pool bonus for Tests silently stops applying

**Describe the bug**
An Active Effect that's supposed to add a bonus to a character's dice pool for certain Tests
(a `Custom`-mode change, applied to a Test) no longer does anything. There's no error or
warning anywhere — the effect is just quietly inert, and the roll dialog's Pool total never
reflects it.

This particular effect is an older one: it was set up on this item a while ago, before a recent
system update, and hasn't been touched since.

**To Reproduce**
Steps to reproduce the behavior:
- Have a Quality/gear item whose Active Effect targets a character's Test dice pool via a
  `Custom`-mode change, authored some time before the recent update mentioned above.
- Roll a Test that the effect applies to.
- The roll dialog's Pool does not include the effect's bonus, and nothing in the console or UI
  indicates why.

**Screenshots**

<img width="1311" height="603" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />

**Versions (please complete the following information):**
- FoundryVTT Version 13.351
- System Version 0.33.0

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — an Active Effect's Changes tab for a "Catlike"
  quality item, showing a `Custom`-mode change applied to a Test, behind a Sneaking Test roll
  dialog whose Pool of 11 does not include any bonus from that effect.

This image is available inside the container and is part of the bug report; read it before making
changes.
