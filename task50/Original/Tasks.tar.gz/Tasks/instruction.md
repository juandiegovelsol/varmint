# Screen does not communicate every detail

The app is not showing all the information in the screen as you see here:

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot
- `/app/.harbor_assets/bug_screenshot_2.png` — bug_screenshot

The screen should transparently reflect the full outcome.

