# Unwrapping step issue (see attached screenshots), and erratic manual entry

When I process a withdrawal of my WETH or a redeem of my staked shares (trSHETHp) and reach the final unwrapping confirmation step, please see the attached screenshots — the issue is visible there and relates to the amount that was withdrawn. The redeem flow has the same problem: the field should reflect the value of what was actually redeemed, not the raw number of shares. 

Additionally, if I try to type in a smaller amount manually, the input field behaves erratically and snaps to the wrong value. 

Fix the logic so that the unwrap step behaves normally, and manual entry of smaller amounts works as expected.

<img width="618" height="516" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />
<img width="600" height="470" alt="Image" src="/app/.harbor_assets/bug_screenshot_2.png" />

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot
- `/app/.harbor_assets/bug_screenshot_2.png` — bug_screenshot

These images are available inside the container and are part of the bug report; read them before making changes.
