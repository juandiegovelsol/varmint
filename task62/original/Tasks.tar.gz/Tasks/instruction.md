# Unwrapping amount defaults to the wrong value and behaves erratically

When I process a withdrawal of my WETH or a redeem of my staked shares (trSHETHp) and reach the final unwrapping confirmation step, the pre-filled amount in the input field is incorrect. 

Please see the attached screenshots for exactly what is happening. The input field defaults to a much larger amount instead of the correct value. 

Additionally, if I try to type in a smaller amount manually, the input field behaves erratically and snaps to the wrong value. 

Fix the logic so that the correct amount is shown in the input field, and manual entry of smaller amounts works as expected.

<img width="618" height="516" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />
<img width="600" height="470" alt="Image" src="/app/.harbor_assets/bug_screenshot_2.png" />

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot
- `/app/.harbor_assets/bug_screenshot_2.png` — bug_screenshot

These images are available inside the container and are part of the bug report; read them before making changes.
