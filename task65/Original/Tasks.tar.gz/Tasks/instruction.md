# Date & time utilities: missing duration format, and the current output has drifted

Our product's shared utilities package provides a set of small, framework-agnostic
date & time formatting helpers (relative time, absolute time, absolute date, combined
date-and-time, ranges). Two things need to be addressed.

## 1. There is no duration format

Opposed to the relative time format (e.g. now, 1 minute ago, 1 day ago), a duration
format displays the absolute length of time (e.g. 2 seconds, 1 hour 30 minutes). The
web platform provides this natively:
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DurationFormat

Add a duration formatter to the same utilities area, following the conventions the
existing formatters already establish there (an options object with `locale` and
`style`, a sensible default style, exposure through the same public surface consumers
already import from). For a duration of 1 hour, 23 minutes and 45 seconds in `en-US`,
the expected outputs are:

| style | output |
| --- | --- |
| (default) | 1h 23m 45s |
| long | 1 hour, 23 minutes, 45 seconds |
| short | 1 hr, 23 min, 45 sec |
| narrow | 1h 23m 45s |
| digital | 1:23:45 |

The first attached screenshot is the design-guidance table for the formats the
utilities already support — reference output, permitted style variants, and which
variant is the default for each format. Note it has no Duration row yet; that is
exactly the gap this request fills.

<img alt="Design guidance: supported date & time formats" src="/app/.harbor_assets/date_time_formats_reference.png" />

## 2. The current output has drifted from the guidance

While preparing this request we rendered our internal demo pages against the current
code, and a number of things are visibly wrong — across more than one utility and in
more than one way. The two demo screenshots are attached. They are laid out to be
self-checking: default-option calls sit beside explicit-style calls, the same value is
shown in several locales side by side, and each demo row states its own configuration
in its caption — so output that is wrong sits directly beside output (or a caption)
that shows what right looks like, and the design-guidance table above states the
conventions the utilities are supposed to follow.

<img alt="Date and time utilities, current rendered output" src="/app/.harbor_assets/datetime_utilities_current.png" />

<img alt="Tag overflow utility, current rendered behaviour" src="/app/.harbor_assets/tag_overflow_current.png" />

Bring the utilities back in line. We consider this done when the new duration format
behaves as specified above and everything shown in the demo screenshots renders the
way the guidance and the demos' own captions imply it should.
