# Inconsistency of Tickspeed visibility

Tickspeed is visible in the Modern UI theme but is not visible in the Classic UI theme at the very beginning of a new game, before the Reality milestone is unlocked.
Both themes should display the Tickspeed stat consistently once it becomes relevant.



![Modern UI](/app/.harbor_assets/bug_modern.png)


![Classic UI](/app/.harbor_assets/bug_classic.png)

