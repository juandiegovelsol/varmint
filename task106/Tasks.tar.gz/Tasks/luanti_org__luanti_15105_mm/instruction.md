# Left floating test board freezes on its first color while the matching board beside it keeps cycling

### What happens
In `recording.mp4` (0:15 total), from about 0:02 to the end, the camera holds on two square boards floating side by side ahead. The right-hand board's color and letter keep cycling — yellow "A", red "B", magenta "C", blue "D" — while the left-hand board stays stuck on the yellow "A" tile for the rest of the clip.

### Expected
Both boards should keep cycling through all four colored letter tiles together at the same pace. The left-hand board should not get stuck on its first tile while the board next to it keeps changing.

### Environment
All

## Attached visual evidence

- `/app/.harbor_assets/recording.mp4`

You can pull individual frames out of the video with `ffmpeg` (installed in the image) to compare the two boards at different moments.

Inspect the attached file before making changes. The video describes observable behavior; it does not prescribe source files, internal names, or an implementation strategy.
