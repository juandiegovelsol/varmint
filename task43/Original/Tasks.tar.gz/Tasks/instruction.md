# Chart readouts stay on screen after keyboard focus has moved on

<img width="558" height="1071" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />

## Expected behavior

The screenshot shows three separate charts on one page, reached one after another with the keyboard.
Only one thing on a page can hold focus at a time, and here it has already moved on to the button at
the top, yet all three charts still show a readout, each one frozen at whatever point it was left
on.

Find and correct the state handling responsible, so that a readout belongs to the chart that
currently has focus and to no other, and a reader who leaves one and comes back is never stranded:
what they see should always match where they are. Mind the difference between leaving and choosing:
what the reader puts away stays away until they move on, and then it returns at once.
