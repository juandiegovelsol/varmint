# Badge sheets print incomplete badges

An organiser prints attendee badges several to a sheet. One slot on the sheet carries a coloured strip and a supporter mark, and they sit below that badge's text rather than within it. The other slots on the sheet carry only text. The export offers more than one arrangement of badges to a sheet, and the same thing happens on each of them.

![Image](/app/.harbor_assets/bug_screenshot_2.png)