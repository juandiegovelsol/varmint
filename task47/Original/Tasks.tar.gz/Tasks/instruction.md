## Description

The **Review settings -> Review scores** page is behaving unpredictably for organisers trying to set up or tidy up their scoring categories. A short screen recording of a session poking at this page is attached, along with a few frames pulled from it — watch the recording closely, since some of what's wrong only becomes clear from the sequence of clicks rather than from any single frame.

At a high level: once you start adding score rows or a whole new category with the **+** controls, the page gives you no clean way to walk any of that back if you change your mind mid-edit, and it isn't consistent about telling you when something you typed won't actually be kept. Rows that end up half-finished, categories that never got a name, and score values that plainly aren't numbers all seem to slip through without the page saying anything useful about it — sometimes nothing is saved and nothing is said, sometimes something ends up saved that clearly shouldn't have been, and on the one occasion a validation error does surface, it shows up as a generic banner rather than pointing at what actually needs fixing.

None of this is exotic — it's the general "the form doesn't push back when it should, and doesn't offer a way out once you've committed to an edit" family of problem — but there is more than one distinct way it shows up on this page. The recording is the fastest way to see the actual sequence of symptoms rather than guess at them from this description.

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.mp4` — bug_screenshot (the screen recording attached to the report)
- `/app/.harbor_assets/bug_screenshot_1_1.png` — bug_screenshot (frame 1 of that recording)
- `/app/.harbor_assets/bug_screenshot_1_2.png` — bug_screenshot (frame 2 of that recording)
- `/app/.harbor_assets/bug_screenshot_1_3.png` — bug_screenshot (frame 3 of that recording)

These files are available inside the container and are part of the bug report; read them before making changes.
