# [BUG] Game just fully crashes upon opening

### Pre-requisites

- [x] I have searched the existing issues
- [x] This issue was encountered (or replicated) on a non-edited Clan

### Description

I am in fullscreen, but I am fairly sure I got an error (image attached is a screenshot taken of a screenrecording, the game and terminal close too fast to see it otherwise). The game straight up doesn't open so I can't check if it doesn't work with fullscreen lmao

/app/.harbor_assets/bug_screenshot_1.png

### Grade

Game-breaking - makes it impossible to play the game

### Gamemode

Expanded Mode

### Challenge cards

_No response_

### Steps to reproduce the behavior

1. Download ClanGen
2. Open ClanGen
3. Cry

### Patrol ID + Outcome Print (if applicable)

_No response_

### Commit # or Game Version Number

0a0cc93

### Error log

<img width="1386" height="672" alt="Image" src="/app/.harbor_assets/bug_screenshot_2.png" />

### Additional context

_No response_

### Screenshots

_No response_


## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot
- `/app/.harbor_assets/bug_screenshot_2.png` — bug_screenshot

These images are available inside the container and are part of the bug report; read them before making changes.
