# A character given its own vertical offset lands in a different place on the canvas than in the exported SVG

A text object in this library lets an individual character be nudged vertically away from the baseline of the line it belongs to, so that one character can sit higher or lower than the characters around it.

Drawn on the canvas, such a text object looks the way it should. Exported to SVG and then viewed, the same text object comes out differently: the character carrying its own vertical offset no longer sits where the canvas puts it, while every other character on the line is unaffected. The two surfaces disagree about that one character.

The canvas rendering is the correct reference. It is not what is wrong here and must not be changed — the exported SVG is the side that has to be brought into agreement with it.

Two still frames of the same text object are provided so the disagreement can be seen directly:

- `/app/.harbor_assets/canvas_render.png` — the canvas rendering.
- `/app/.harbor_assets/exported_render.png` — the exported SVG rendering of that same text object.

Bring the exported SVG into agreement with the canvas. Agreement must hold for a character offset upward and for a character offset downward, when more than one offset character appears on the same line, and for an offset character on any line of a text with several lines.

The disagreement between the two surfaces is not confined to where a character sits. Agreement must also hold for the thickness of text decorations, both where the text object declares one and where an individual character declares its own, and that thickness must not vary with the scale applied to the text object. It must hold as well when the text follows a path, where each character is rotated to the curve.
