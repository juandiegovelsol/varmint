#define SDL_MAIN_HANDLED 1
#include "dialog_selectscenario.h"
#include "maps_fileinfo.h"
#include <gtest/gtest.h>
#include <string>

extern int g_showMessageCallCount;

class TestListBox : public ScenarioListBox {
public:
    using Interface::ListBox<Maps::FileInfo>::ActionListPressRight;
    explicit TestListBox() : ScenarioListBox(fheroes2::Point(0, 0)) {}
};

TEST(ScenarioListBox, IconAreaRightClickDoesNotShowPopup)
{
    g_showMessageCallCount = 0;

    TestListBox listbox;
    Maps::FileInfo info;
    info.file = "/some/path/map.mp2";
    info.name = "TestMap";
    info._version = GameVersion::SUCCESSION_WARS;

    fheroes2::Point iconPos( 10, 5 );
    listbox.ActionListPressRight( info, iconPos, 0, 0 );

    EXPECT_EQ(g_showMessageCallCount, 0)
        << "Right-clicking in the icon area triggered fheroes2::showMessage "
        << g_showMessageCallCount << " time(s). It must not show the map-info popup.";
}

int main(int argc, char ** argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
