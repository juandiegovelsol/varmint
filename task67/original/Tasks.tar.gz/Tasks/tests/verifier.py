#!/usr/bin/env python3
"""
verifier.py — parses GoogleTest JUnit XML output and writes a reward.

Reward policy:
  1.0 — every f2p test passes AND every p2p test passes (or p2p is empty) AND the rubric
        (if any verdict is available) did not fail
  0.5 — some f2p pass but not all, OR p2p regression, OR all tests pass but the rubric failed
  0.0 — no f2p passes, or report missing / failed to parse

The rubric can only ever withhold a 1.0, never turn a genuine 0.0 result into something
worse, and a missing/unavailable rubric verdict never blocks a 1.0.

This task has:
  f2p = ["ScenarioListBox.IconAreaRightClickDoesNotShowPopup"]
  p2p = []  (no pre-existing tests to guard)
"""
import json
import os
import re
import sys
import xml.etree.ElementTree as ET

CONF = json.load(open('/tests/config.json'))
F2P  = CONF['f2p']
P2P  = CONF['p2p']
REPORT = '/logs/verifier/report.xml'
REWARD  = '/logs/verifier/reward.txt'
REWARD_JSON = '/logs/verifier/reward.json'


def load_results():
    """Return {test_identifier: 'pass'|'fail'|'skip'} from JUnit XML."""
    results = {}
    if not os.path.exists(REPORT):
        return results
    try:
        tree = ET.parse(REPORT)
    except ET.ParseError as exc:
        print(f"[verifier] XML parse error: {exc}", file=sys.stderr)
        return results
    for tc in tree.iter('testcase'):
        classname = tc.get('classname', '')
        name      = tc.get('name', '')
        # GoogleTest JUnit XML uses '.' as separator in classname; normalise to '::'
        dotted    = f"{classname}.{name}".strip('.')
        colon     = f"{classname}::{name}".strip(':')
        failed    = any(c.tag in ('failure', 'error') for c in tc)
        skipped   = any(c.tag == 'skipped' for c in tc)
        status    = 'skip' if skipped else ('fail' if failed else 'pass')
        results[dotted]  = status
        results[colon]   = status
    return results


def matched(idents, results):
    """Match each configured identifier to a result (substring / regex tolerant)."""
    out = {}
    for ident in idents:
        hit = next(
            (v for k, v in results.items()
             if ident in k or re.search(re.escape(ident), k)),
            None,
        )
        out[ident] = hit or 'missing'
    return out


def parse_rubric_arg(argv):
    """--rubric "pass"|"fail"|"" -> "pass"/"fail"/None. None (missing/unrecognised/empty)
    means no verdict is available yet and must never withhold a 1.0."""
    if "--rubric" not in argv:
        return None
    i = argv.index("--rubric")
    value = argv[i + 1].strip() if i + 1 < len(argv) else ""
    return value if value in ("pass", "fail") else None


def main():
    rubric = parse_rubric_arg(sys.argv[1:])

    r    = load_results()
    f2p  = matched(F2P, r)
    p2p  = matched(P2P, r)

    f2p_pass = [k for k, v in f2p.items() if v == 'pass']
    p2p_pass = [k for k, v in p2p.items() if v == 'pass']

    all_f2p = len(f2p_pass) == len(F2P) and len(F2P) > 0
    all_p2p = len(p2p_pass) == len(P2P)   # vacuously true if P2P is empty

    if all_f2p and all_p2p:
        reward = 0.5 if rubric == 'fail' else 1.0
    elif f2p_pass and (not all_p2p or not all_f2p):
        reward = 0.5
    else:
        reward = 0.0

    os.makedirs(os.path.dirname(REWARD), exist_ok=True)
    with open(REWARD, 'w') as fh:
        fh.write(str(reward))

    # reward.json MUST stay a flat map of numbers (harbor parses it as dict[str, float]
    # and prefers it over reward.txt; a nested value aborts the trial before scoring).
    detail = {'reward': reward, 'rubric_pass': {'pass': 1, 'fail': 0}.get(rubric, -1)}
    for name, v in f2p.items():
        detail[f'f2p::{name}'] = 1.0 if v == 'pass' else 0.0
    for name, v in p2p.items():
        detail[f'p2p::{name}'] = 1.0 if v == 'pass' else 0.0
    try:
        with open(REWARD_JSON, 'w') as fh:
            json.dump(detail, fh, indent=2)
    except Exception as exc:
        print(f"WARNING: could not write {REWARD_JSON}: {exc}", file=sys.stderr)

    print(json.dumps({'reward': reward, 'rubric': rubric, 'f2p': f2p, 'p2p': p2p,
                       'report_keys': list(r.keys())}))


if __name__ == '__main__':
    main()
