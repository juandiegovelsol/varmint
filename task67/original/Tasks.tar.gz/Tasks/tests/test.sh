#!/usr/bin/env bash
# Behavioral verifier for ihhub__fheroes2-4924-mm.
#
# Applies the test patch (adds stubs.cpp + test_actionlistpressright.cpp),
# compiles the test against the CANDIDATE's dialog_selectscenario.cpp,
# links with GoogleTest, runs the test, and calls verifier.py.
#
# BEHAVIORAL: the test calls ScenarioListBox::ActionListPressRight() and checks
# whether fheroes2::showMessage was invoked — it NEVER greps source code.
#
# BASE  (no fix) : ActionListPressRight calls showMessage → test FAILS → reward 0.0
# FIXED (fix app): ActionListPressRight is a no-op → test PASSES    → reward 1.0
set -uo pipefail

mkdir -p /logs/verifier
STDOUT_LOG=/logs/verifier/test-stdout.txt
STDERR_LOG=/logs/verifier/test-stderr.txt
REPORT=/logs/verifier/report.xml

: > "$STDOUT_LOG"
: > "$STDERR_LOG"

ensure_reward() { [ -f /logs/verifier/reward.txt ] || echo 0 > /logs/verifier/reward.txt; }
trap ensure_reward EXIT

cd /app || { echo "no /app" | tee -a "$STDERR_LOG"; exit 1; }

# -----------------------------------------------------------------------
# Step 1 — reset test-patch paths from harbor_base so the apply is idempotent
# -----------------------------------------------------------------------
_patch_paths=$(
  { sed -n 's#^diff --git a/\(.*\) b/.*#\1#p' /tests/test.patch
    sed -n 's#^diff --git a/.* b/\(.*\)#\1#p' /tests/test.patch
  } | sort -u )
for _p in $_patch_paths; do
  git -C /app checkout harbor_base -- "$_p" 2>/dev/null || rm -f "/app/$_p" 2>/dev/null || true
done
git -C /app clean -fdq -- $(printf '%s\n' $_patch_paths | xargs -r -n1 dirname | sort -u) 2>/dev/null || true

# -----------------------------------------------------------------------
# Step 2 — apply test.patch (adds harbor_test_src/ test files)
# -----------------------------------------------------------------------
echo "== applying test.patch ==" | tee -a "$STDOUT_LOG"
git apply --binary /tests/test.patch 2>>"$STDERR_LOG" \
  || git apply /tests/test.patch 2>>"$STDERR_LOG" \
  || patch -p1 -i /tests/test.patch 2>>"$STDERR_LOG" \
  || { echo "ERROR: could not apply test.patch" | tee -a "$STDERR_LOG"; exit 1; }

# -----------------------------------------------------------------------
# Step 3 — build gtest from the source vendored under /tests/vendor (offline,
# no network: this is plain GoogleTest source, not a Debian package, and it
# is never baked into the agent-visible image -- only /tests/ carries it,
# supplied fresh at verify time).
# -----------------------------------------------------------------------
echo "== building test deps ==" | tee -a "$STDOUT_LOG"
if [ ! -f /usr/local/lib/libgtest.a ]; then
  GTEST_BUILD_DIR=/tmp/gtest-build
  cmake -S /tests/vendor/googletest -B "$GTEST_BUILD_DIR" \
        -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX=/usr/local -DBUILD_GMOCK=OFF \
    >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
    && cmake --build "$GTEST_BUILD_DIR" --parallel 4 >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
    && cmake --install "$GTEST_BUILD_DIR" >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
    && rm -rf "$GTEST_BUILD_DIR" \
    || { echo "ERROR: could not build libgtest.a from /tests/vendor/googletest" | tee -a "$STDERR_LOG"; exit 1; }
fi
ls /usr/local/lib/libgtest.a >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || { echo "ERROR: libgtest.a not found" | tee -a "$STDERR_LOG"; exit 1; }

# -----------------------------------------------------------------------
# Step 4 — compile and link the test
# -----------------------------------------------------------------------
echo "== compiling test ==" | tee -a "$STDOUT_LOG"

IFLAGS="
  -I /app/src/fheroes2/agg
  -I /app/src/fheroes2/ai
  -I /app/src/fheroes2/army
  -I /app/src/fheroes2/battle
  -I /app/src/fheroes2/campaign
  -I /app/src/fheroes2/castle
  -I /app/src/fheroes2/dialog
  -I /app/src/fheroes2/game
  -I /app/src/fheroes2/gui
  -I /app/src/fheroes2/h2d
  -I /app/src/fheroes2/heroes
  -I /app/src/fheroes2/image
  -I /app/src/fheroes2/kingdom
  -I /app/src/fheroes2/maps
  -I /app/src/fheroes2/monster
  -I /app/src/fheroes2/objects
  -I /app/src/fheroes2/pocketpc
  -I /app/src/fheroes2/resource
  -I /app/src/fheroes2/spell
  -I /app/src/fheroes2/system
  -I /app/src/fheroes2/world
  -I /app/src/engine"

SDL_CFLAGS=$(sdl2-config --cflags 2>/dev/null || echo "-I/usr/include/SDL2 -D_REENTRANT")
CFLAGS="-std=c++11 ${SDL_CFLAGS}"

BUILD_DIR=/tmp/harbor_test_build
mkdir -p "$BUILD_DIR"

g++ $CFLAGS -c /app/harbor_test_src/stubs.cpp            $IFLAGS -o "$BUILD_DIR/stubs.o"     2>>"$STDERR_LOG" || { echo "ERROR: stubs.cpp compile failed"  | tee -a "$STDERR_LOG"; exit 1; }
g++ $CFLAGS -c /app/src/fheroes2/dialog/dialog_selectscenario.cpp $IFLAGS -o "$BUILD_DIR/dialog.o" 2>>"$STDERR_LOG" || { echo "ERROR: dialog.cpp compile failed"  | tee -a "$STDERR_LOG"; exit 1; }
g++ $CFLAGS -c /app/harbor_test_src/test_actionlistpressright.cpp $IFLAGS -o "$BUILD_DIR/test_main.o" 2>>"$STDERR_LOG" || { echo "ERROR: test.cpp compile failed"    | tee -a "$STDERR_LOG"; exit 1; }

g++ -std=c++11 "$BUILD_DIR/stubs.o" "$BUILD_DIR/dialog.o" "$BUILD_DIR/test_main.o" \
    -lgtest -lpthread -lSDL2 \
    -o "$BUILD_DIR/test_selectscenario" 2>>"$STDERR_LOG" \
  || { echo "ERROR: link failed" | tee -a "$STDERR_LOG"; exit 1; }

echo "== build succeeded ==" | tee -a "$STDOUT_LOG"

# -----------------------------------------------------------------------
# Step 5 — run test with JUnit XML output
# -----------------------------------------------------------------------
echo "== running f2p tests ==" | tee -a "$STDOUT_LOG"
"$BUILD_DIR/test_selectscenario" \
    --gtest_output="xml:${REPORT}" \
    >>"$STDOUT_LOG" 2>>"$STDERR_LOG" \
  || echo "(test process exited non-zero; parsing report)" | tee -a "$STDOUT_LOG"

# -----------------------------------------------------------------------
# Step 6 — compute reward
# -----------------------------------------------------------------------
echo "== computing reward ==" | tee -a "$STDOUT_LOG"
# Rubric judge - SUB-AGENT backend: no API key, no network. On the first pass there is no
# verdict yet, so judge.py writes a judge request under /logs/verifier/judge/ and prints
# nothing. The `|| echo ""` is load-bearing: the judge must never be able to fail the run.
RUBRIC=""
if [ -f /tests/rubrics.json ]; then
  RUBRIC=$(python3 /tests/judge.py --rubrics /tests/rubrics.json --repo /app \
             2>/logs/verifier/judge.log || echo "")
  echo "Rubric verdict: ${RUBRIC:-pending (judge request written; rescore after grading)}"
fi

python3 /tests/verifier.py --rubric "${RUBRIC:-}" 2>>"$STDERR_LOG" | tee -a "$STDOUT_LOG"
echo "reward=$(cat /logs/verifier/reward.txt 2>/dev/null)" | tee -a "$STDOUT_LOG"
