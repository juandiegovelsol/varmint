# Scenario selection window: icon areas are no longer accessible

### Describe the bug

In the scenario selection dialog, right-clicking on the icon columns no longer works correctly. The right-click areas for various icons overlap incorrectly, preventing access to the expected icon-specific information.

The screenshots below illustrate the problem. The second screenshot shows the expected correct behavior for an icon-area right-click. bug_4.png shows the incorrect behavior instead. bug_6.png and bug_8.png are additional captures of that same incorrect result from the original bug report — they are byte-identical to bug_4.png, not screenshots of different icon columns:

![Idle state](/app/.harbor_assets/bug_1.png)
![Expected behavior - correct tooltip](/app/.harbor_assets/bug_2.png)
![Idle state - different map](/app/.harbor_assets/bug_3.png)
![Bug - wrong popup on an icon area](/app/.harbor_assets/bug_4.png)

![Idle state - third variation](/app/.harbor_assets/bug_5.png)
![Bug - same wrong popup, repeated capture](/app/.harbor_assets/bug_6.png)

![Idle state - fourth variation](/app/.harbor_assets/bug_7.png)
![Bug - same wrong popup, repeated capture](/app/.harbor_assets/bug_8.png)

Fix the scenario selection dialog so that right-clicking on each icon area works correctly.
