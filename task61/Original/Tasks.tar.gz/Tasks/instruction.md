# [FEATURE] Fractional Value For Adept Power AP

**Describe the solution you'd like**

Please change the input field of AP for Adept Powers to accept fractional values, so that Elemental Body can be implemented correctly.

<img width="813" height="756" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` -- screenshot from the issue, showing the "Elemental
  Body" Adept Power item's sheet (Details tab). Its Action/Damage section reads "Base Damage: 2
  * Magic", and directly below it, highlighted in red, an "AP" (Armor Penetration) field
  currently holding the whole number `0` next to a "* Magic" formula-operator dropdown. The
  reporter wants this AP field to accept a fractional coefficient (e.g. `0.5`) instead of only
  whole numbers.

This image is available inside the container and is part of the feature/bug report; read it
before making changes.
