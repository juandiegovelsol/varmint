# Some elements are not displaying correctly

Some elements in the image are showing values that don't look right. Please find those elements.

![bug_screenshot_1](/app/.harbor_assets/bug_screenshot_1.png)

![bug_screenshot_2](/app/.harbor_assets/bug_screenshot_2.png)
