# Draft overview: one field's label doesn't match what it reports

## Context

A draft that has gone through approval shows a summary panel at the top of its
overview page. That panel describes the validation run against the draft.

## The problem

The label on one of the panel's fields is borrowed from elsewhere in the product —
it's the term the platform applies to the workflow status a draft occupies. The
panel isn't about that. It's about the validation.

The consequence is that a reader has no way to tell, from the label alone, whether
the field in front of them concerns the draft's position in the workflow or the
validation the rest of the panel describes. Those are unrelated concerns.

## Constraints

The values displayed in the panel are accurate and should be preserved exactly as
they are. The change should not be observable anywhere else in the product.

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot

These images are available inside the container and are part of the bug report;
read them before making changes.