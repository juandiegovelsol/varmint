# [BUG] New sprite powers are filed under the wrong section header

**Describe the bug**
The Sprite Powers tab of a sprite actor sheet splits powers across more than one section
header, and each header carries its own `+Add` button. A power created from one of those
buttons is not filed under the section it was created from. The attached screenshot marks
the affected headers and their `+Add` buttons, and shows where the new powers land instead.

**Screenshots**
<img width="993" height="329" alt="Image" src="/app/.harbor_assets/bug_screenshot_1.png" />

## Attached visual evidence

- `/app/.harbor_assets/bug_screenshot_1.png` — bug_screenshot: the Sprite Powers tab, with
  the affected section headers and their `+Add` buttons annotated.

This image is available inside the container and is part of the bug report; read it before
making changes.
